"""Verify all three modes, source identities, totals, and reported medians."""
from collections import Counter
import hashlib
import itertools
import json
from pathlib import Path
import re
import statistics

ROOT = Path(__file__).resolve().parent
compile_data = json.loads((ROOT / 'compile.json').read_text())
runtime = json.loads((ROOT / 'runtime.json').read_text())
previous = json.loads((ROOT.parent / 'workload-evidence/test-corpus.json').read_text())
modes = ('plain', 'pytest', 'capture')
expected_orders = set(itertools.permutations(modes))
checks = {}

for name, record, harness in (
        ('compile', compile_data, 'compare_compile.py'),
        ('runtime', runtime, 'compare_runtime.py')):
    assert len(record['blocks']) == 6
    assert {tuple(block['order']) for block in record['blocks']} == expected_orders
    assert record['harness_sha256'] == hashlib.sha256((ROOT / harness).read_bytes()).hexdigest()
    assert record['executable_sha256'] == hashlib.sha256(Path(record['executable']).read_bytes()).hexdigest()
assert compile_data['executable_sha256'] == runtime['executable_sha256']
assert compile_data['pytest_commit'] == runtime['pytest_commit']
assert compile_data['files'] == len(compile_data['rows']) == 612
assert compile_data['assertions'] == previous['assertions'] == 71205
assert compile_data['input_manifest_sha256'] == hashlib.sha256(
    (ROOT.parent / 'workload-evidence/test-corpus.json').read_bytes()).hexdigest()
previous_hashes = {row['path']: row['sha256'] for row in previous['rows']}
assert {row['path']: row['sha256'] for row in compile_data['rows']} == previous_hashes
for row in compile_data['rows']:
    assert row['sha256'] == hashlib.sha256((Path(previous['root']) / row['path']).read_bytes()).hexdigest()
for mode in modes:
    for key in ('bytecode_bytes', 'marshal_bytes'):
        assert compile_data['totals'][mode][key] == sum(row['modes'][mode][key] for row in compile_data['rows'])
    assert compile_data['median_seconds'][mode] == statistics.median(
        block['seconds'][mode] for block in compile_data['blocks'])
reference = runtime['blocks'][0]['runs'][modes[0]]
expected_modules = {str(ROOT.parent / 'workload-evidence/vendor/sympy' / name)
                    for name in (*runtime['inputs'], 'conftest.py')}
for block_index, block in enumerate(runtime['blocks'], 1):
    for mode, run in block['runs'].items():
        assert run['exit_code'] == 0
        assert run['nodeids'] == reference['nodeids']
        assert run['reports'] == reference['reports']
        assert run['cpu'] == [runtime['cpu']]
        assert set(run['compiled']) == (set() if mode == 'plain' else expected_modules)
        log = (ROOT / 'runtime-runs' / f'{block_index:02}-{mode}.log').read_text()
        assert re.search(r'194 passed, 7 skipped, 4 xfailed, 4 warnings in ', log)
        assert len(run['code_checks']) == 4
        for actual in run['code_checks'].values():
            assert actual == {'capture': mode == 'capture', 'pytest': mode == 'pytest'}
        for key, median in runtime['medians'][mode].items():
            assert median == statistics.median(b['runs'][mode][key] for b in runtime['blocks'])
for path, digest in runtime['inputs'].items():
    assert digest == hashlib.sha256((ROOT.parent / 'workload-evidence/vendor/sympy' / path).read_bytes()).hexdigest()
source_manifest = json.loads((ROOT / 'source-manifest.json').read_text())
for path, digest in source_manifest['files'].items():
    assert digest == hashlib.sha256((ROOT / path).read_bytes()).hexdigest()

checks['files'] = compile_data['files']
checks['assertions'] = compile_data['assertions']
checks['collected_tests'] = len(reference['nodeids'])
checks['outcomes'] = dict(Counter((r['when'] + ':' + r['outcome']) for r in reference['reports']))
checks['terminal_outcomes'] = {'passed': 194, 'skipped': 7, 'xfailed': 4, 'warnings': 4}
checks['terminal_outcomes_note'] = (
    'The recorder stores xfail reasons as strings. An empty xfail reason is '
    'indistinguishable from a skip there. Every terminal log independently '
    'confirms seven skips and four expected failures.')
checks['compile'] = {}
checks['runtime'] = {}
for mode in modes:
    samples = [b['seconds'][mode] for b in compile_data['blocks']]
    checks['compile'][mode] = {'median_seconds': statistics.median(samples),
                               'min_seconds': min(samples), 'max_seconds': max(samples),
                               **compile_data['totals'][mode]}
    checks['runtime'][mode] = {}
    for key in ('command_seconds', 'test_loop_seconds'):
        samples = [b['runs'][mode][key] for b in runtime['blocks']]
        checks['runtime'][mode][key] = {'median': statistics.median(samples),
                                       'min': min(samples), 'max': max(samples)}
checks['capture_vs_pytest'] = {
    'compile_ratio': compile_data['median_seconds']['capture'] / compile_data['median_seconds']['pytest'],
    **{key + '_ratio': compile_data['totals']['capture'][key] / compile_data['totals']['pytest'][key]
       for key in ('bytecode_bytes', 'marshal_bytes')},
    **{key + '_ratio': runtime['medians']['capture'][key] / runtime['medians']['pytest'][key]
       for key in ('command_seconds', 'test_loop_seconds')},
}
compile_reductions = [1 - b['seconds']['capture'] / b['seconds']['pytest']
                      for b in compile_data['blocks']]
checks['compile_reduction_within_blocks'] = {
    'fractions': compile_reductions, 'min': min(compile_reductions),
    'max': max(compile_reductions)}
minima = [checks['runtime'][mode]['test_loop_seconds']['min'] for mode in modes]
checks['test_loop_minima_spread_seconds'] = max(minima) - min(minima)
checks['paired_differences_seconds'] = {}
for key in ('command_seconds', 'test_loop_seconds'):
    differences = [b['runs']['capture'][key] - b['runs']['pytest'][key]
                   for b in runtime['blocks']]
    checks['paired_differences_seconds'][key] = {
        'capture_minus_pytest': differences,
        'median': statistics.median(differences),
        'min': min(differences), 'max': max(differences)}
(ROOT / 'measurement-check.json').write_text(json.dumps(checks, indent=2) + '\n')
print(json.dumps(checks, indent=2))
