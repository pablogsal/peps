Snazzy Asserts: local PEP draft

snazzy-asserts.pdf: current PEP, 8 pages.
snazzy-asserts.html: browser version.
final-draft.rst: PEP source copy.
native-assertion-diagnostics-notes.html: detailed API and earlier microbenchmarks.
native-assertion-diagnostics-research.html: sources, methods, and raw records.
snazzy-asserts-assets.zip: source and measurement evidence.

The pep-native-assertion-diagnostics PDF and HTML files are compatibility
copies. The source files are in:
/home/pablogsal/github/cpython/native-assert-prototype-20261018/Tools/assert_details

Reference Implementation contains one link to the published prototype commit.
The companion notes retain implementation status and source locations.
Performance now has one compact table and a short account of assertion
cost, compilation, and the selected test run. The research notes retain
the full results and method.
Implementation uses Python-style pseudocode to connect the original assertion
to frame slots and the callback. A short bytecode subsection explains the
three new instructions. The technical notes retain the full bytecode example.

This revision compares pytest's assertion rewrite with compiler capture and
ordinary assertions in the same prototype executable. It retains one opt-in
feature, off by default, with a CLI option and a compiler flag. It does not
change interpreter code. The title appears once in the PDF. There is no
expression-tree diagram, Use by pytest section, or performance plot.

Compilation covers 612 SymPy 1.14.0 test files with 71,205 assertions.
Median times are 1.24 seconds for ordinary asserts, 48.57 for pytest,
and 14.10 for compiler capture. Capture emits 77% less bytecode than pytest,
but only 12% less serialized code. Its serialized size remains 5.65 times
ordinary code. All modes use identical source bytes and the same build.

Execution covers four unchanged SymPy core test files through pytest.
Every run reports 194 passed, 7 skipped, and 4 expected failures.
Six fresh processes per mode use all mode orders. Empty bytecode-cache
prefixes exclude .pyc reuse; filesystem caches are warm. Command time
includes all source imports, compilation, collection, execution, and shutdown.
Test-loop time includes fixtures, expected failures, and reports. It does
not isolate assertion-failure cost. The runtime ranges overlap and vary
substantially across blocks. The PEP makes no runtime speed claim.

pytest-evidence contains the new harnesses, raw observations, all command
logs, source hashes, code-mode checks, arithmetic, and paired differences.
Both diagnostic modes compile exactly the same five modules: the four test
files and their conftest. Ordinary mode uses no rewrite hook. The source
uses pytest commit 420cf37a3fc8c03c9a4769c2635a03773d27be10. A marshal
round-trip preserves the invoice example's values and explanation.

The archive includes the measured pytest and dependency source with their
licenses. It excludes installed workload packages. Their pinned versions
and wheel hashes are in workload-evidence/packages.json. Each evidence
directory has its own manifest. Reproduction commands are in the research
notes and pytest-evidence/README.txt.

workload-evidence retains three adapted pyperformance workloads and five
source corpora. The research notes retain their full tables and methods.
These include 702 standard library source files, with 543 assertions.
Capture adds 29,202 bytecode bytes and 277,041 serialized bytes there.
The three library workloads' 95% intervals include zero change.

The older evidence directory retains assertion-loop and warm formatter
measurements. The eleven nonconstant loops have geometric mean time ratios
of 1.67 for pytest and 1.86 for capture, relative to ordinary assertions.
These ratios do not estimate application slowdown. Its older library
corpus selects only files with assertions, not the whole standard library.

check_document.py checks RST and example syntax and produces browser HTML.
render_companions.py produces companion HTML documents.
render_pdf.py produces the PDF and checks page boundaries.
workload-evidence/check_measurements.py checks the earlier raw records.
pytest-evidence/check_measurements.py checks the three-mode comparison.

before-diagram-removal preserves the draft with the expression-tree diagram.
before-pseudocode preserves the draft with bytecode in the main explanation.
before-performance-cut preserves the longer Performance section.
before-reference-link preserves the draft before that section became one link.
before-pytest-comparison preserves the previous PDF and sources.
before-workload-tables preserves the older plots and sources.
before-single-control preserves the earlier three-flag draft.
before-snazzy-figures and before-research-revision retain older versions.

pseudocode-review records the compiler example checks and a focused Claude
review of the source-to-callback explanation.
performance-edit-review records the scan of 659 PEP documents and the
Claude editorial pass that selected the shorter Performance section.
pytest-review records two earlier Claude passes over the comparison method
and prose. Each pass retains its prompt, reviewed text, result, and
decisions. Earlier reviews in concise-reviews, single-control-review, and
workload-review cover earlier drafts, not this revision.

The draft uses PEPs 657, 701, and 758 as style references. PEP 709 provides
an example of separate reporting for microbenchmarks and application work.
Wikipedia:Signs_of_AI_writing is an editorial reference supplied by the user.

The draft is unnumbered. Pickle behavior and dispatcher-error context still
need implementation work. Module naming, report suppression, and minimum
graph coverage remain open. The prototype is on the snazzy-asserts branch of
pablogsal/cpython. The PEP source and artifacts are on the matching branch
of pablogsal/peps.
